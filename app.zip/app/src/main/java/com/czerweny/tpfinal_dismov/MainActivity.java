package com.czerweny.tpfinal_dismov;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.czerweny.tpfinal_dismov.databinding.ActivityMainBinding;
import com.firebase.ui.auth.AuthUI;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    static private final int AUTH_ACTIVITY = 42;

    ActivityMainBinding binding;
    FirebaseAuth mAuth;
    FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        this.signOut();
        firebaseUser = mAuth.getCurrentUser();

        if (firebaseUser == null) {
            launchAuth();
        } else {
            //userModel.setUsuario(firebaseUser.getUid());
            //armarPantallaPrincipal();
        }
    }

    @SuppressWarnings("deprecation")
    void launchAuth(){
        // new AuthUI.IdpConfig.PhoneBuilder().build()
        // new AuthUI.IdpConfig.TwitterBuilder().build()
        List<AuthUI.IdpConfig> providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build(),
                new AuthUI.IdpConfig.GoogleBuilder().build(),
                new AuthUI.IdpConfig.FacebookBuilder().build());

        // Create and launch sign-in intent
        Intent signInIntent = AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .build();
        startActivityForResult(signInIntent, AUTH_ACTIVITY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == AUTH_ACTIVITY) {
            if (resultCode == RESULT_OK) {
                Intent homeIntent = new Intent(this, MainActivity.class);
                // startActivity(homeIntent);

                // firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                // assert (firebaseUser != null);
                // String idUsuario = firebaseUser.getUid();
                // String nombre = firebaseUser.getDisplayName();
                // String email = firebaseUser.getEmail();
                // if (email == null) {
                //    for (UserInfo profile : firebaseUser.getProviderData()) {
                //         email = profile.getEmail();
                //     }
                // }
                // Repositorio.guardarUsuario(new Usuario(idUsuario, nombre, email));
                // modeloUsuario.setUsuario(idUsuario);
                // armarPantallaPrincipal();
            } else {
                finish();
            }
        }
    }

    void signOut(){
        mAuth.signOut();
    }


}